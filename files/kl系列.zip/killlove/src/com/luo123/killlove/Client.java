package com.luo123.killlove;

import com.jzj.socket.SocketTransceiver;
import com.jzj.socket.TcpClient;

import java.net.URL;

import static java.lang.Thread.sleep;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Client implements Runnable {

    public static int port = 6666;
    public static String URL = "127.0.0.1";

    private static boolean connected = false;

    @Override
    public void run() {
        client.connect(URL, port);

    }

    public static TcpClient getClient() {
        return client;

    }

    static TcpClient client = new TcpClient() {

        @Override
        public void onReceive(SocketTransceiver st, String s) {
            Network.net(s);
        }

        @Override
        public void onDisconnect(SocketTransceiver st) {

            System.out.println("链接已断开");
            for (int i = 0; i < TaskManager.getTm().task.size(); i++) {
                TaskManager.getTm().stoptask(i);
            }
        }
        //断线关闭任务，防止重连后重复添加多个

        @Override
        public void onConnect(SocketTransceiver transceiver) {
            System.out.println("链接成功");

            connected = true;

        }

        @Override
        public void onConnectFailed() {

            System.out.println("链接失败");
            try {
                sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("正在重连....");
            connect(URL, port);  //重连
        }

    };
}