package com.luo123.killlove;

import java.text.SimpleDateFormat;
import java.util.Date;

import static java.lang.Thread.sleep;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Showcount implements Runnable {
    private Task ta;
    private int id;

    public Showcount(Task ta, int id) {
        this.ta = ta;
        this.id = id;
    }

    @Override
    public void run() {
        while (ta.isstop != true) {
            SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");//设置日期格式

            System.out.println("-----------"+df.format(new Date())+"-----------");
            System.out.println("任务"+id+"成功攻击: " + ta.getcount() + "次");
            System.out.println("任务"+id+"错误: " + ta.geterrs() + "次");
            System.out.println("任务"+id+"上次错误信息: " + ta.getlasterr());
            try {
                sleep(10 * 1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }
}
