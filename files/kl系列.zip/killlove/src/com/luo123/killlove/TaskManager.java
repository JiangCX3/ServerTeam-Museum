package com.luo123.killlove;

import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Administrator on 2016/8/2.
 */
public class TaskManager {
    private TaskManager() {
    }

    static TaskManager tm = new TaskManager();

    public static TaskManager getTm() {
        return tm;
    }

    Map<Integer, String> url = new TreeMap<Integer, String>(); //id url
    Map<Integer, Integer> thread = new TreeMap<Integer, Integer>(); //id 线程数


    Map<Integer, Task> task = new TreeMap<Integer, Task>(); //id 对象

    public void addtask(int id, int ths, String url) {
        this.url.put(id, url);
        this.thread.put(id, ths);

        Task task = new Task(id);
        this.task.put(id, task);
        task.run();

        //吧任务信息放入集合

    }

    public void stoptask(int id) {
        if (url.get(id) != null) {
            task.get(id).kill();   //运行kill方法结束cc子线程
            this.url.remove(id);
            this.thread.remove(id);  //移除线程url等信息
            this.task.remove(id);  //移除对象
        }

    }


}
