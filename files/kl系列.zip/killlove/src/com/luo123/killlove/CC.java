package com.luo123.killlove;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


/**
 * Created by Administrator on 2016/6/11.
 */
public class CC implements Runnable {
    private Task ta;

    public CC(Task ta) {
        this.ta = ta;
    }

    @Override
    public void run() {
        HttpURLConnection connection;
        InputStream urlStream;
        URL url;
        while (ta.isstop != true) {

            try {
                url = new java.net.URL(ta.url);//得到URL
                connection = (java.net.HttpURLConnection) url.openConnection();
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36");

                connection.connect();
                urlStream = connection.getInputStream();
                if (urlStream != null) {
                    ta.count();
                    urlStream.close();

                }
                Thread.sleep(1);
            } catch (InterruptedException e) {

                e.getMessage();
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
            } catch (MalformedURLException e) {
                //   e.printStackTrace();
                ta.setlasterr("错误: url不正确");
            ta.counterr();
            } catch (java.net.ConnectException e) {
                ta.setlasterr("错误:链接失败");
                ta.counterr();
            } catch (java.net.SocketTimeoutException e) {
                ta.setlasterr("错误:链接被重置");
                ta.counterr();
            } catch (java.net.SocketException e) {
                ta.setlasterr("错误:软件造成的连接终止");
                ta.counterr();
            } catch (java.io.IOException e) {
                ta.setlasterr("错误:服务器错误");
                ta.counterr();
            }
        }


    }
}
