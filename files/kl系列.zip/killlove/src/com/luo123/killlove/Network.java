package com.luo123.killlove;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Network {
    public static void net(String text) {
        //
        if (text.indexOf("new") != -1) {//包含new；  新建任务

          /*  String urlget = "url:(?<grp0>.+?);"; //获取url
            String thsget = "ths:([^\\D]+);"; //获取线程数
            String idget = "id:([^\\D]+);"; //获取id
            String url = Pattern.compile(urlget).matcher(text).group(1);
            int ths = Integer.parseInt(Pattern.compile(thsget).matcher(text).group(1));
            int id = Integer.parseInt(Pattern.compile(idget).matcher(text).group(1));*/

            String[] a = text.split("!!~");
            //new id url ths
            //0   1   2   3
            System.out.println("任务："+a[1]+" 已启动");
            TaskManager.getTm().addtask(Integer.parseInt(a[1]), Integer.parseInt(a[3]), a[2]);

            Client.getClient().getTransceiver().send("successnew!!~" + a[1] );
        }
//接收数据处理

        if (text.indexOf("stop") != -1) { //关闭任务
            String[] a = text.split("!!~");
            System.out.println("正在关闭任务 "+ a[1]);
            Client.getClient().getTransceiver().send("successstop!!~"+a[1]);
            TaskManager.getTm().stoptask(Integer.parseInt(a[1]));
        }
    }
}
