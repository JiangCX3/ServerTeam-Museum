package com.luo123.killloveplus;

import java.net.InetSocketAddress;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Administrator on 2016/10/28.
 */
public class Klproxy {


    static ArrayList<String> httpproxysip = new ArrayList<String>();

    private static ArrayList<Integer> httpproxysport = new ArrayList<Integer>();

    static ArrayList<java.net.Proxy> httpproxyobject = new ArrayList<java.net.Proxy>();


     static void addhttpproxys(Set<String> proxys) {
        Iterator it = proxys.iterator();

        Pattern p = Pattern.compile("(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9]):\\d{0,5}");  //匹配ip:端口

        while (it.hasNext()) {
            Matcher m = p.matcher((String) it.next());    //循环添加ip端口到map
            m.find();
            String[] ipport;
           try {
               ipport = m.group(0).split(":");  //将端口和ip分开

               httpproxysip.add(ipport[0]);
               httpproxysport.add(Integer.parseInt(ipport[1]));
           }catch (Exception ignored){

           }
        }
    }

     static void connectallhttpproxy() {
        for (int i = 0; i < httpproxysip.size(); i++) {
            httpproxyobject.add(new java.net.Proxy(java.net.Proxy.Type.HTTP, new InetSocketAddress(httpproxysip.get(i), httpproxysport.get(i))));
        }

    }

}

