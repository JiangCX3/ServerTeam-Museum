package com.luo123.killloveplus;

import java.io.IOException;

import static java.lang.Thread.sleep;


/**
 * Created by Administrator on 2016/10/28.
 */
public class Main {

    private static String config;
    public static void main(String[] args) {
        System.out.println("killlove+ by:luo123");
        if (args.length == 0) {
            System.out.println("请输入配置文件路径");
            System.exit(0);
        }
        try {
            config = FileUtils.readFile(args[0]);    //读取配置文件
        } catch (IOException e) {
            e.printStackTrace();
        }
       Config.readconfig(config);   //解析配置文件

        try {
           Klproxy.addhttpproxys(FileUtils.readFileLine(Config.httpproxy) );  //读取代理文件并处理
        } catch (IOException e) {
            e.printStackTrace();
        }

      //  System.out.println(Klproxy.httpproxysip);
       // System.out.println(Klproxy.httpproxysport);
        Klproxy.connectallhttpproxy();

        if (args.length == 2){
            if (args[1].equals("test")){
                Proxytest.starttest(Klproxy.httpproxyobject);
            }


        }else {
            System.out.println("目标url: "+Config.url);
            System.out.println("代理数: "+ Klproxy.httpproxyobject.size());
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            TaskManager.startcc();
        }

    }
}

