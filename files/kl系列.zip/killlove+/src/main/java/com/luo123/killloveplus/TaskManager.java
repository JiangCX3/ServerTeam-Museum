package com.luo123.killloveplus;

import java.util.Random;

/**
 * Created by Administrator on 2016/10/28.
 */
public class TaskManager {

    public static int success , filed;
    public static void  startcc(){
        if (Config.autothreads ){
            for (int i = 0; i < Klproxy.httpproxyobject.size(); i++) {
                new CC(Klproxy.httpproxyobject.get(i)).start();    //获取代理对象列表吧所有对象都创建一个线程开始cc

            }
        }else{
            Random ran = new Random();
            for (int i = 0; i < Config.threads; i++) {

                new CC(Klproxy.httpproxyobject.get(ran.nextInt(Klproxy.httpproxysip.size()))).start();    //获取httpip列表长度并随机选择一个ip作为代理开始cc

            }
        }

    }


}

