package com.luo123.killloveplus;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Administrator on 2016/10/28.
 */
public class CC extends Thread {

    java.net.Proxy proxy;
    public CC(java.net.Proxy proxy){
        this.proxy = proxy;
    }

    @Override
    public void run() {
        HttpURLConnection connection;
        InputStream urlStream;
        URL url;
        while (true) {

            try {
                url = new java.net.URL(Config.url);//得到URL
                connection = (java.net.HttpURLConnection) url.openConnection(proxy);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36");

                connection.connect();
                urlStream = connection.getInputStream();
                if (urlStream != null) {
                    TaskManager.success++;
                    System.out.println(TaskManager.success +"/"+TaskManager.filed+" | "+proxy.address().toString()+" 请求发送成功");
                    urlStream.close();

                }
                Thread.sleep(1);
            } catch (InterruptedException e) {

                e.getMessage();
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
            } catch (MalformedURLException e) {
                //   e.printStackTrace();
                TaskManager.filed++;
                System.out.println(TaskManager.success +"/"+TaskManager.filed+" | "+proxy.address().toString()+" 错误：url不正确");

            } catch (java.net.ConnectException e) {
                TaskManager.filed++;
                System.out.println(TaskManager.success +"/"+TaskManager.filed+" | "+proxy.address().toString()+" 错误：链接失败");

            } catch (java.net.SocketTimeoutException e) {
                TaskManager.filed++;
                System.out.println(TaskManager.success +"/"+TaskManager.filed+" | "+proxy.address().toString()+" 错误：链接被重置");

            } catch (java.net.SocketException e) {
                TaskManager.filed++;
                System.out.println(TaskManager.success +"/"+TaskManager.filed+" | "+proxy.address().toString()+" 错误：软件造成的链接终止");

            } catch (java.io.IOException e) {
                TaskManager.filed++;
                System.out.println(TaskManager.success +"/"+TaskManager.filed+" | "+proxy.address().toString()+" 错误：服务器错误");

            }
        }
    }
}
