package com.luo123.killloveplus;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by Administrator on 2016/10/29.
 */
public class Proxytestthread extends Thread {

    java.net.Proxy proxy;

    URL url = null;

    HttpURLConnection connection = null;
    InputStream urlStream = null;

    public Proxytestthread() {

        try {
            url = new URL("http://www.baidu.com");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while (true) {
            if ((proxy = Proxytest.next()) == null) {
                Proxytest.finish();
                break;
            }
                         try {
                    connection = (HttpURLConnection) url.openConnection(proxy);
                    connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36");
                    connection.setReadTimeout(2000);
                    connection.connect();
                    urlStream = connection.getInputStream();

                    if (urlStream != null) {
                        try {
                            urlStream.close();
                            System.out.println(proxy.address() + " 验证成功");
                            Proxytest.success(proxy);
                            Proxytest.okproxys++;
                            //成功
                        } catch (IOException e) {
                            System.out.println(proxy.address() + " 验证失败");
                        }
                    }
                } catch (IOException e) {
                    System.out.println(proxy.address() + " 验证失败");

            }

        }
    }
}
