package com.luo123.killloveplus;


import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;


/**
 * Created by Administrator on 2016/10/28.
 */
public class Config {
    public static String url, httpproxy;
    public static int threads;
    public static boolean autothreads;
    public static int testthreads;


    public static void readconfig(String config) {
        JSONTokener jsonTokener = new JSONTokener(config);
        JSONObject configJSONObject;
        try {

            configJSONObject = (JSONObject) jsonTokener.nextValue();
            url = configJSONObject.getString("url");
            threads = configJSONObject.getInt("threads");
            autothreads = configJSONObject.getBoolean("autothreads");
            httpproxy = configJSONObject.getString("httpproxy");
            testthreads = configJSONObject.getInt("testthreads");
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}




