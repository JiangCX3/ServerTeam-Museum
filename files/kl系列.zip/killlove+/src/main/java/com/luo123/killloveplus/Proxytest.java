package com.luo123.killloveplus;

import java.io.*;
import java.net.Proxy;
import java.util.ArrayList;


/**
 * Created by Administrator on 2016/10/29.
 */
public class Proxytest {

    public static ArrayList<java.net.Proxy> successproxys = new ArrayList<java.net.Proxy>();
    private static ArrayList<Proxy> waittest;
    public static int okproxys;

    public static void starttest(ArrayList<java.net.Proxy> proxys) {
        waittest = proxys;
        for (int i = 0; i < Config.testthreads; i++) {
            new Proxytestthread().start();
        }

    }


    public static void success(java.net.Proxy proxy) {
        successproxys.add(proxy);

    }

    static int i = Klproxy.httpproxyobject.size();

    public static Proxy next() {

        i--;
        if (i < 0) {
            return null;
        }
        return waittest.get(i);
    }

    static int a = Config.testthreads;

    public static void finish() {
        a--;
        if (a == 0) {

            String fileNameTemp = "ips_tested.txt";   //文件名称
            File filePath = new File(fileNameTemp);
            if (!filePath.exists()) {
                try {
                    filePath.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            FileWriter fw = null;
            try {
                fw = new FileWriter(filePath);
            } catch (IOException e) {
                e.printStackTrace();
            }

            PrintWriter pw = new PrintWriter(fw);
            for (int i = 0; i < successproxys.size(); i++) {
                pw.println(successproxys.get(i).address());             //写文件
            }
            pw.flush();
            pw.close();
            try {
                fw.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.println("验证完毕,有效代理数: " + okproxys);
            System.exit(0);

        }
    }
}
