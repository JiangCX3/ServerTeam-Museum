package com.luo123.killloveserver;

import com.jzj.socket.SocketTransceiver;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Network {

    public static void in(SocketTransceiver so, String text) {
        //    System.out.println(text);

        String[] a = text.split("!!~");
        switch (a[0]) {
            case "successnew":
                System.out.println("客户端" + so.getInetAddress() + "成功接收任务" + a[1]);
                break;
            case "successstop":
                System.out.println("客户端" + so.getInetAddress() + "成功停止任务" + a[1]);
                break;

        }
    }
    //接收数据


    public static void newtask(int id) {

        Clientmanager.getInstance().sendtext("new!!~" + id + "!!~" + Taskmanager.getTaskmanager().object.get(id).getUrl() + "!!~" + Taskmanager.getTaskmanager().object.get(id).getThreads());
        //new id url ths
        //0   1   2   3
    }

    public static void stop(int id) {

        Clientmanager.getInstance().sendtext("stop!!~" + id);
    }

}
