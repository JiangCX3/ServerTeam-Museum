package com.luo123.killloveserver;


import com.jzj.socket.SocketTransceiver;
import com.jzj.socket.TcpServer;
import com.luo123.killloveserver.Timers.Testtimer;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("killlove server 1.1 by:luo123");
       if (args.length<1){
           System.out.println("请设置端口号");
           return;
       }
        TcpServer server = new TcpServer(Integer.parseInt(args[0])) {

            @Override
            public void onConnect(SocketTransceiver client) {

                System.out.println("客户端" + client.getInetAddress() + "已连接");

                Clientmanager.getInstance().addclient(client);  //添加到管理器

            }

            @Override
            public void onConnectFailed() {
                System.out.println("客户端链接失败");
            }

            @Override
            public void onReceive(SocketTransceiver client, String s) {
                Network.in(client, s);
            }

            @Override
            public void onDisconnect(SocketTransceiver client) {
                System.out.println("客户端" + client.getInetAddress() + "已断开连接");
                Clientmanager.getInstance().removeclient(client);
                client.stop();
            }

            @Override
            public void onServerStop() {

                for (int i = 0; i < Clientmanager.getInstance().client.size(); i++) {
                    Clientmanager.getInstance().client.get(i).stop();

                }
            }
        };

        server.start();
        System.out.println("服务器已运行在端口"+Integer.parseInt(args[0])+"上");

        new Thread(new Testtimer()).start();  //启动链接测试线程
        new Thread(new Command()).start();   //启动控制台命令处理线程
    }
}





