package com.luo123.killloveserver.Timers;

import com.luo123.killloveserver.Clientmanager;

import static java.lang.Thread.sleep;

/**
 * Created by Administrator on 2016/8/3.
 */
public class Testtimer implements Runnable {
    @Override
    public void run() {

        while (true){
            Clientmanager.getInstance().testconnect();
            try {
                sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
