package com.luo123.killloveserver;


/**
 * Created by Administrator on 2016/8/2.
 */
public class Task implements Runnable {
    private int id;
    private int threads;
    private String url;

    public Task(int id, String url, int threads) {
        this.id = id;
        this.url = url;
        this.threads = threads;
    }

    public int getId() {
        return id;
    }

    public String getUrl() {
        return url;
    }

    public int getThreads() {
        return threads;
    }

    public boolean isstop = false;

    @Override
    public void run() {
        Network.newtask(id);  //发送新任务数据包
    }


    void stop() {
        isstop = true;
    }
}
