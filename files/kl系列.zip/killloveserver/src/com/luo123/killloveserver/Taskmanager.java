package com.luo123.killloveserver;

import java.util.Map;
import java.util.TreeMap;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Taskmanager {
    private Taskmanager() {
    }

    public static  int id =0;
    static Taskmanager taskmanager = new Taskmanager();

    public static Taskmanager getTaskmanager() {
        return taskmanager;
    }



    Map<Integer, Task> object = new TreeMap<>();  //id 任务对象


    public void addtask(int ths, String url) {
        Task task = new Task(id,url,ths);

        Thread cctask = new Thread(task);
        object.put(id, task);
        cctask.start();
        System.out.println("id为"+id);
        id++;
        //吧任务信息放入集合

    }

    public void stoptask(int id) {
        object.get(id).stop();
        Network.stop(id);
        object.remove(id);

    }
    //删除集合中的任务
}
