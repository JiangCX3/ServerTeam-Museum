package com.luo123.killlove;

import com.jzj.socket.TcpClient;

import static java.lang.Thread.sleep;

/**
 * Created by Administrator on 2016/8/2.
 */
public class Keepconnect implements Runnable {

    @Override
    public void run() {
      while (true){
          try{
              Client.getClient().getTransceiver().send("ok");

          }catch(Exception se){
            //  se.printStackTrace();

              Client.getClient().connect(Client.URL , Client.port);
          }
          try {
              sleep(600);
          } catch (InterruptedException e) {
              e.printStackTrace();
          }
      }

    }
}
