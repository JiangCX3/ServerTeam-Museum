package com.luo123.killlove;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2016/6/11.
 */
public class Task{

    public String url;
    private String lasterr = "无";
    public long attacks;
    public long errs;
    public int id;
    public boolean isstop = false;
    private Thread shoucount;
    List<Thread> ccths = new ArrayList<Thread>();


    public Task(int id) {
        this.id = id;
        url = TaskManager.getTm().url.get(id);
    }


    public void run() {
        shoucount = new Thread(new Showcount(this, id));
        shoucount.start();
        for (int i = 0; i < TaskManager.getTm().thread.get(id); i++) {
            CC at = new CC(this);
            Thread t = new Thread(at);
            ccths.add(t);
            t.start();
        }

    }

    public void kill() {
        isstop =true;
    }

    public void count() {
        attacks++;
    }
    //cc成功计数

    public void counterr() {
        errs++;
    }
//错误计数
    public long getcount() {
        return attacks;

    }

    public long geterrs() {
        return errs;

    }

    public void setlasterr(String err) {
        lasterr = err;
    }
//设置上次错误
    public String getlasterr() {
        return lasterr;
    }

}