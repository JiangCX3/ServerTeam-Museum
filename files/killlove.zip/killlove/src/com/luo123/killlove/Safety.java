package com.luo123.killlove;

import com.jzj.socket.SocketTransceiver;
import com.jzj.socket.TcpClient;

import static java.lang.Thread.sleep;

/**
 * Created by Administrator on 2016/8/6.
 */
public class Safety {
    private static String in;
    private static boolean err = false;
    static TcpClient client = new TcpClient() {
        @Override
        public void onReceive(SocketTransceiver st, String s) {
            in = s;
        }

        @Override
        public void onDisconnect(SocketTransceiver st) {

        }

        @Override
        public void onConnect(SocketTransceiver transceiver) {

        }

        @Override
        public void onConnectFailed() {
            err = true;
        }

    };

    public static boolean Verification(String url) {
        client.connect("127.0.0.1", 6665);

        try {
            sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (err == true){
           return false; //无法连接不通过验证
       }
        try{
            String[] a = in.split("!"); //分割字符串

            for (int i = 0; i < a.length; i++) {//遍历分割后的字符串

                if (url.indexOf(a[1]) > -1) {
                    return false;  //查找字符串，如果存在返回大于-1
                }
            }

            client.getTransceiver().stop();//关闭连接
            return true;
        }catch (Exception e){
            return false;
        }



    }

}
