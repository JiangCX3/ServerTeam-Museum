package cn.mcsao;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import java.util.*;
import cn.mcsao.Activity;


/**
 * Created by luo123 on 2016/4/25.
 * MASAO java客户端
 * 为了学java重写的，技术不高，大神勿喷
 */
public class Main {
   public static String command;
    static String  host = "s1.server.mso.ink";//服务器ip
    static int port = 51888;//服务器端口
    public static void main(String [] args) throws IOException {
        System.out.println("MinecraftServerAO - <java dev0.0.1> By：<luo123> <所有官版开发者名,分号分离>\n");
      System.out.println("欢迎来到MinecraftServerAO");
        Scanner scanner = new Scanner(System.in);

    //    System.out.println("请键入Triangle ID: ");
    //    String name = scanner.nextLine();
     //   System.out.println("请键入Triangle 密码: ");
     //   String password = scanner.nextLine();
      //   System.out.println("正在连接服务器....");
          String name = "test" ,password = "123456";
        try {
            Socket socket = new Socket(host, port);

            OutputStream os = socket.getOutputStream();//字节输出流
            PrintWriter pw = new PrintWriter(os);//将输出流包装成打印流
            pw.write("<ID"+ name +"/ID> <PWD"+ password +"/PWD>");//发送数据
            pw.flush();
            socket.shutdownOutput();
            System.out.println("登陆中....");
            //10秒未收到数据自动退出
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                public void run() {
                    System.out.println("登陆超时，请稍后再试");
                    System.exit(0);
                }
            }, 10000);
            BufferedReader is = new BufferedReader(new InputStreamReader(socket.getInputStream())); //由Socket对象得到输入流，并构造相应的BufferedReader对象
            String read = is.readLine();//返回内容

            if (read.equals("true")){
        System.out.println("欢迎回来:"+name);
        timer.cancel();
                read = "null";
           while (true){
              read = is.readLine();
              Activity activity = new Activity();
             activity.start();
           }
            }
            if (read.equals("false")) {
                System.out.println("登陆失败，可能是用户名不存在或密码不正确");
                timer.cancel();
            }
        } catch (Exception e) {
              System.out.println("出错：" + e);   //出错，则打印出错信息
              System.exit(0);
        }
    }

/* public static void register() throws IOException{
Scanner scanner = new Scanner(System.in);
    System.out.println("请输入你的邮箱:");
    String name = scanner.nextLine();
    System.out.println("请输入你的密码:");
    String password = scanner.nextLine();
    System.out.println("请确认你的密码:");
    if (password.equals(scanner.nextLine())){
System.out.println("你的注册请求即将提交审核，请留下你常用的邮箱，当审核通过后，我们会通知你");
        System.out.println("正在提交请求...");
        Socket socket = new Socket(host, port);
        OutputStream os = socket.getOutputStream();//字节输出流
        PrintWriter pw = new PrintWriter(os);//将输出流包装成打印流
        pw.write("<INFOregister/INFO> <ID"+ name +"ID> <PWD"+ password +"PWD>");//发送数据
        pw.flush();
        socket.shutdownOutput();
        os.close(); //关闭Socket输出流
        socket.close(); //关闭Socket
        System.out.println("请求已推送！请等待回复！");
    }else {
        System.out.println("两次密码不符合，请重新注册");

    }*/

}


