﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace fucklove
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("想关掉我，没门");
            e.Cancel = true;//阻止关闭
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("想关掉吗", "boom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                MessageBox.Show("你想多了", "boom", MessageBoxButtons.OK, MessageBoxIcon.Information);
                timer1.Enabled = true;
                Hide();
            }
            else
            {
                MessageBox.Show("没错我是不会让你关掉的", "boom", MessageBoxButtons.OK, MessageBoxIcon.Information);
               timer1.Enabled = true;
                Hide(); 
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            MessageBox.Show("Fuck xxxx", "boom", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
